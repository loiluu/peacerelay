EthProof  = require('./lib/ethProof')
EthVerify = require('./lib/ethVerify')

module.exports = {EthProof, EthVerify}
